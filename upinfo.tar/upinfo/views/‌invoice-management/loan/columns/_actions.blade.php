
<button class="btn btn-icon btn-active-light-primary w-30px h-30px me-3" data-permission-id="{{ $invoice->id }}" data-bs-toggle="modal" data-bs-target="#kt_modal_show_pdf">
<i class="fas fa-file-pdf fa-3x" style="color: grey;"></i>
</button>