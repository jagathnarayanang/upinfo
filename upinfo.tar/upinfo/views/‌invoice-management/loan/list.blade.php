<x-default-layout>
    @section('title', 'Loan Details')

    <div class="card">
        <div class="card-header border-0 pt-6">
       

            <div class="card-toolbar">
                <div class="d-flex justify-content-end" data-kt-user-table-toolbar="base">
                    <button type="button" class="btn btn-primary" id="search_val">
                       Process Data
                    </button>  &nbsp;&nbsp;&nbsp;&nbsp;
                </div>

            </div>
        </div>

        <div class="card-body py-4">
            <div class="table-responsive">
                {{ $dataTable->table() }}
            </div>
        </div>
    </div>

    @push('scripts')
        {{ $dataTable->scripts() }}
        <script>
            $(function() {
                var table = window.LaravelDataTables['loan-table'];
                console.log(table);
                if (!table) {
                    console.error("loan-table DataTable not found!");
                    return;
                }

                var searchInput = document.getElementById('mySearchInput');
                var dateRangePicker = $('#kt_daterangepicker_1');
                var searchButton = document.getElementById('search_val');
                var resetButton = document.getElementById('reset_btn');

                // Initialize date range picker
                dateRangePicker.daterangepicker({
                    opens: 'left'
                });

                function applySearchFilters() {
                    table.search(searchInput.value).draw();
                }

                function applyDateFilters() {
                    const dateRange = dateRangePicker.val();

                    // Clear existing search
                    table.search('').columns().search('');

                    // Apply text search
                    if (searchInput.value) {
                        table.search(searchInput.value);
                    }

                    // Apply date range filter
                    const [start, end] = dateRange.split(' - ');
                    table.column(2).search(start + '|' + end);

                    table.draw();
                }

                // Event listeners
                searchInput.addEventListener('keyup', applySearchFilters);

                dateRangePicker.on('apply.daterangepicker', function(ev, picker) {
                    applyDateFilters();
                });

                searchButton.addEventListener('click', applySearchFilters);

                resetButton.addEventListener('click', function() {
                    searchInput.value = '';
                    dateRangePicker.val('');
                    table.search('').columns().search('').draw();
                });

                // Livewire event listener
                document.addEventListener('livewire:init', function () {
                    Livewire.on('success', function () {
                        $('#kt_modal_add_user').modal('hide');
                        table.ajax.reload();
                    });
                });
            });
        </script>
    @endpush
</x-default-layout>
